/*======================================================
************   App Resize Actions   ************
======================================================*/
app.onResize = function () {
    app.sizeNavbars();
    // Something else could be here
};